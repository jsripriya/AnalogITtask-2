<!-- resources/views/display-results.blade.php -->

@extends('layouts.app')

@section('content')

    <h1>Results</h1>
    <p>{{ $resultMessage }}</p>

@endsection
